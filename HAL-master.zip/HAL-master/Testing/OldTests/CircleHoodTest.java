package Testing.OldTests;

import HAL.Util;

public class CircleHoodTest {
    public static void main(String[] args) {
        System.out.println(Util.CircleHood(true,12).length/3);
    }
}
