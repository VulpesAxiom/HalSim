package Testing.OldTests;

/**
 * Created by Rafael on 11/16/2017.
 */
public class RandTest {
    public static void main(String[] args) {
    }
}
