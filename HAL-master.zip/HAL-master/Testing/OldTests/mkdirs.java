package Testing.OldTests;

import static HAL.Util.MakeDirs;

/**
 * Created by Rafael on 9/19/2017.
 */
public class mkdirs {
    public static void main(String[] args) {
        System.out.println(MakeDirs("test/ing"));
    }
}
