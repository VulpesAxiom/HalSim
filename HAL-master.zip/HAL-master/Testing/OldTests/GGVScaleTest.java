package Testing.OldTests;

/**
 * Created by Rafael on 10/16/2017.
 */
public class GGVScaleTest {
    public static void main(String[] args) {
    //    UIWindow win=new UIWindow("testing",true,true);
    //    UIGrid ggv=new UIGrid(10,10,10,100);
    //    win.AddCol(0,ggv);
    //    ggv.SetPix(5,5,RGB(1,1,1));
    //    win.RunGui();
    }
}
