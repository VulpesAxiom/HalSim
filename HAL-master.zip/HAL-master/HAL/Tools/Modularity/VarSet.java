package HAL.Tools.Modularity;

public interface VarSet {
    double[] GetVars();
    void SetVars(double[]newVars);
}
