package HAL.Interfaces;

@FunctionalInterface
public interface Coords3DAction {
    public void Action(int x,int y,int z);
}
