package HAL.Interfaces;

@FunctionalInterface
public interface IntToInt {
    int Eval(int in);
}
