package HAL.Interfaces;

@FunctionalInterface
public interface DoubleArrayToVoid {
    void Action(double[]in);
}
