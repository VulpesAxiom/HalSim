package HAL.Interfaces;

@FunctionalInterface
public interface IndexCoords2DAction {
    void Action(int i,int x,int y);
}
