package HAL.Interfaces;

/**
 * Created by rafael on 4/8/17.
 */
@FunctionalInterface
public interface GAMutantToString<T> {
    String MutantToString(T mut);
}
