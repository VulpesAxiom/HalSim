package HAL.Interfaces;

/**
 * Created by Rafael on 7/24/2017.
 */
@FunctionalInterface
public interface DoubleToInt {
    public int DoubleToInt(double in);
}
