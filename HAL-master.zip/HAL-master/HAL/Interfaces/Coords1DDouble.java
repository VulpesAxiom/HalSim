package HAL.Interfaces;

@FunctionalInterface
public interface Coords1DDouble {
    double GenDouble(int x);
}
