package HAL.Interfaces;

@FunctionalInterface
public interface Coords3DDouble {
    double GenDouble(int x, int y, int z);
}
