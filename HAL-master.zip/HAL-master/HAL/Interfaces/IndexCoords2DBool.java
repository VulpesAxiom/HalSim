package HAL.Interfaces;

@FunctionalInterface
public interface IndexCoords2DBool {
    boolean Eval(int i, int x, int y);
}
