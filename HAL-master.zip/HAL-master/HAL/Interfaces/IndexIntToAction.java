package HAL.Interfaces;

@FunctionalInterface
public interface IndexIntToAction {
    void Action(int index,int val);
}
