package HAL.Interfaces;

/**
 * Created by rafael on 8/26/17.
 */
@FunctionalInterface
public interface GridDiff2MultiThreadFunction {
    public void GridDiff2MulitThreadFunction(int x, int y, int i);
}
