package HAL.Interfaces;

@FunctionalInterface
public interface Coords1DInt {
    int GenInt(int x);
}
