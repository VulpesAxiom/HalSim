package HAL.Interfaces;

@FunctionalInterface
public interface DoubleToAction {
    void Action(double val);
}
