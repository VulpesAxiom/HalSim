package HAL.Interfaces;

@FunctionalInterface
public interface KeyResponse {
    public void Response(char Character,int keyCode);
}
