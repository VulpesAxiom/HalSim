package HAL.Interfaces;

@FunctionalInterface
public interface IndexBool {
    boolean Eval(int i);
}
