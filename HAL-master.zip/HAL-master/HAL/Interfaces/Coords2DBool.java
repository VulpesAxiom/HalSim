package HAL.Interfaces;

@FunctionalInterface
public interface Coords2DBool {
    boolean Eval(int x,int y);
}
