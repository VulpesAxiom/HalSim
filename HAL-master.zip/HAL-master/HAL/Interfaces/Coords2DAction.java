package HAL.Interfaces;

@FunctionalInterface
public interface Coords2DAction {
    void Action(int x,int y);
}
