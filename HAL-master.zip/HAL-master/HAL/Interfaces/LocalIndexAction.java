package HAL.Interfaces;

@FunctionalInterface
public interface LocalIndexAction {
    public void Action(int i);
}
