package HAL.Interfaces;

/**
 * Created by bravorr on 5/31/17.
 */
@FunctionalInterface
public interface DistToForceMap{
    double DistToForce(double rad);
}
