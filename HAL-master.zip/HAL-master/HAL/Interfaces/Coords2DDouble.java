package HAL.Interfaces;

@FunctionalInterface
public interface Coords2DDouble {
    double GenDouble(int x,int y);
}
