package HAL.Interfaces;

@FunctionalInterface
public interface Coords3DBool {
    public boolean Eval(int x, int y,int z);
}
