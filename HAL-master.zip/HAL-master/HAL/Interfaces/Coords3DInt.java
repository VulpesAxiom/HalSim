package HAL.Interfaces;

@FunctionalInterface
public interface Coords3DInt {
    int GenInt(int x, int y, int z);
}
