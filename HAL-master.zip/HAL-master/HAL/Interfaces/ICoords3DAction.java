package HAL.Interfaces;

@FunctionalInterface
public interface ICoords3DAction {
    void Action(int i,int x, int y, int z);
}
