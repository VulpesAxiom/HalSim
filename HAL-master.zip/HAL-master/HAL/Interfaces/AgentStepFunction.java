package HAL.Interfaces;

/**
 * Created by rafael on 8/26/17.
 */
@FunctionalInterface
public interface AgentStepFunction <T>{
    void AgentStepFunction(T agent);
}
