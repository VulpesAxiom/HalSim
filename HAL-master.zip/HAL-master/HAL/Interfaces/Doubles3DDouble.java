package HAL.Interfaces;

public interface Doubles3DDouble {
    double GenDouble(double x,double y,double z);
}
