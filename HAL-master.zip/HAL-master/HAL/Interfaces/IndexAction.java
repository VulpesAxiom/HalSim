package HAL.Interfaces;

@FunctionalInterface
public interface IndexAction {
    void Action(int i);
}
