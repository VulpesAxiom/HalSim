package HAL.Interfaces;

@FunctionalInterface
public interface VoidFunction {
    public void Execute();
}
