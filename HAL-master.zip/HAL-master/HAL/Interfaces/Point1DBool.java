package HAL.Interfaces;

@FunctionalInterface
public interface Point1DBool {
    boolean Eval(double x);
}
