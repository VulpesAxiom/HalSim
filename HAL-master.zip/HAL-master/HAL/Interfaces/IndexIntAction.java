package HAL.Interfaces;

@FunctionalInterface
public interface IndexIntAction {
    void Action(int i, int val);
}
