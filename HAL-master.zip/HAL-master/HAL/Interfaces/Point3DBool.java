package HAL.Interfaces;

@FunctionalInterface
public interface Point3DBool {
    boolean Eval(double x, double y,double z);
}
