package HAL.Interfaces;

public interface Coords6DDouble {
    double GenDouble(int x1,int y1,int p1,int x2,int y2,int p2);
}
