package HAL.Interfaces;

@FunctionalInterface
public interface IntDoubleToVoid {
    public void Eval(int i,double d);
}
