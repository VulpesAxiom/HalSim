package HAL.Interfaces;

@FunctionalInterface
public interface IsEntry1Before2 {
   boolean Compare(int i1,int i2);
}
