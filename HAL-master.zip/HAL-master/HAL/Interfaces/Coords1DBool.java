package HAL.Interfaces;

@FunctionalInterface
public interface Coords1DBool {
    boolean Eval(int x);
}
