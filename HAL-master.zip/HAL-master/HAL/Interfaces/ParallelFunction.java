package HAL.Interfaces;

@FunctionalInterface
public interface ParallelFunction {
    void Run(int runIndex);
}
