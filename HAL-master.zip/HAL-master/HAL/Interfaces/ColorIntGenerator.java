package HAL.Interfaces;

@FunctionalInterface
public interface ColorIntGenerator {
    int GenColorInt();
}
