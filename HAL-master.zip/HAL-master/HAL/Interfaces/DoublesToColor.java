package HAL.Interfaces;

/**
 * Created by Rafael on 10/13/2017.
 */
@FunctionalInterface
public interface DoublesToColor {
    int GenColor(double val1,double val2);
}
