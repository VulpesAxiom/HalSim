package HAL.Interfaces;

public interface GenDouble {
    double GenDouble();
}
