package HAL.Interfaces;

@FunctionalInterface
public interface IntToBool {
    boolean Eval(int num);
}
