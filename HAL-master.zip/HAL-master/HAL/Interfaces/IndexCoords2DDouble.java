package HAL.Interfaces;

@FunctionalInterface
public interface IndexCoords2DDouble {
    public double Eval(int i,int x,int y);
}
