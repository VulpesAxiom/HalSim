package HAL.Interfaces;

@FunctionalInterface
public interface Coords2DInt {
    int GenInt(int x,int y);
}
