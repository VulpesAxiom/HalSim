package HAL.Interfaces;

@FunctionalInterface
public interface IntToDouble {
    double GenDouble(int val);
}
