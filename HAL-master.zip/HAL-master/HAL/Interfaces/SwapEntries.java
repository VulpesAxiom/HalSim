package HAL.Interfaces;

@FunctionalInterface
public interface SwapEntries {
    void Swap(int i1,int i2);
}
