package HAL.Interfaces;

public interface DoubleToDoubles {
    double[]GenDoubles(double val);
}
