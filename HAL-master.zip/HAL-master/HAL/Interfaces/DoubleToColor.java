package HAL.Interfaces;

/**
 * Created by Rafael on 10/13/2017.
 */
@FunctionalInterface
public interface DoubleToColor {
    int GenColor(double val);
}
