package HAL.Interfaces;

@FunctionalInterface
public interface IndexCoords3DAction {
    void Action(int i, int x, int y,int z);
}
