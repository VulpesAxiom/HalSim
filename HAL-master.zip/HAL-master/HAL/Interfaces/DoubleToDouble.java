package HAL.Interfaces;

/**
 * Created by Rafael on 9/18/2017.
 */
@FunctionalInterface
public interface DoubleToDouble {
    public double Eval(double in);
}
