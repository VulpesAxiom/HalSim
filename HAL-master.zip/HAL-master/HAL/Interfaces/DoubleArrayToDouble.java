package HAL.Interfaces;

@FunctionalInterface
public interface DoubleArrayToDouble {
    double Eval(double[] in);
}
