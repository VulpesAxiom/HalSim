package HAL.Interfaces;

@FunctionalInterface
public interface Point2DBool {
    boolean Eval(double x,double y);
}
