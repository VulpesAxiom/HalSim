package HAL.Interfaces;

/**
 * Created by bravorr on 7/18/17.
 */
@FunctionalInterface
public interface AgentToColorInt<T> {
    public int AgentToColor(T agent);
}
