package HAL.Interfaces;

public interface Doubles2DDouble {
    double GenDouble(double x,double y);
}
