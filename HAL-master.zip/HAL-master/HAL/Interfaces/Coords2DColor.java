package HAL.Interfaces;

@FunctionalInterface
public interface Coords2DColor {
    public int SetPix(int x,int y);
}
