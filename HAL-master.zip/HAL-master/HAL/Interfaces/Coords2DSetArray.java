package HAL.Interfaces;

/**
 * Created by Rafael on 10/20/2017.
 */
@FunctionalInterface
public interface Coords2DSetArray {
    void SetArray(int x, int y, double[] out);
}
