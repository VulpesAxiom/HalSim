package HAL.Interfaces;

import HAL.Gui.UIGrid;

public interface DrawFunction {
    void Draw(UIGrid drawHere);
}
