package HAL.Interfaces;

@FunctionalInterface
public interface IndexLongAction {
    void Action(int i, long val);
}
