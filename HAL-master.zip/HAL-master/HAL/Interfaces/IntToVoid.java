package HAL.Interfaces;

@FunctionalInterface
public interface IntToVoid {
    void Eval(int num);
}
