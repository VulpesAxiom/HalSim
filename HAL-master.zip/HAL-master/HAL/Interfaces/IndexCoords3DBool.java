package HAL.Interfaces;

@FunctionalInterface
public interface IndexCoords3DBool {
    boolean Eval(int i, int x, int y, int z);
}
